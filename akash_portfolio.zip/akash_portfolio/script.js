
// Simple scroll reveal
document.addEventListener('DOMContentLoaded', function(){
  const cards = document.querySelectorAll('.card');
  const reveal = function() {
    for (const c of cards) {
      const r = c.getBoundingClientRect();
      if (r.top < window.innerHeight - 80) c.classList.add('show');
    }
  }
  reveal();
  window.addEventListener('scroll', reveal);
});
